package devops.tadigital;
public interface IntegrationTest {

}
